var Ruby = new THREE.Object3D();

function rubyinit(){

  const objLoader = new THREE.OBJLoader();
  objLoader.setPath('/Charblender/Points/');

  const mtlLoader = new THREE.MTLLoader();
  mtlLoader.setPath('/Charblender/Points/');



  new Promise((resolve) => {
    mtlLoader.load('Ruby.mtl', (materials) => {
      resolve(materials);
    });
  })
  .then((materials) => {
    materials.preload();
    objLoader.setMaterials(materials);
    objLoader.load('Ruby.obj', (object) => {
      object.castShadow = true;
      object.receiveShadow = true
      Ruby.add(object);


    });
  });
}


function genruby(){
    temp = Ruby.clone();
    console.log(temp);
    Coininit();
  return temp;
}
